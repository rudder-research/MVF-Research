"""
VCF QUICK FIX - Single Command for Google Colab

INSTRUCTIONS:
1. Copy this entire file
2. Paste into a new Colab cell
3. Run the cell
4. Done!

This will automatically:
- Fix all import statements
- Create missing __init__.py files
- Set up proper data directories
- Move data files to correct locations
- Create backups before making changes
"""

# Mount Google Drive (if not already mounted)
try:
    from google.colab import drive
    drive.mount('/content/drive', force_remount=False)
except:
    pass

import re
import shutil
from pathlib import Path
from datetime import datetime

BASE_PATH = Path("/content/drive/MyDrive/VCF-RESEARCH")
BACKUP_DIR = BASE_PATH / f"_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
BACKUP_DIR.mkdir(parents=True, exist_ok=True)

print("╔" + "═" * 68 + "╗")
print("║" + " " * 20 + "VCF QUICK FIX SCRIPT" + " " * 28 + "║")
print("╚" + "═" * 68 + "╝\n")

fixes = 0

# 1. Create __init__.py files
print("1️⃣  Creating __init__.py files...")
for pkg in ["vcf", "vcf/core", "vcf/data", "vcf/analysis", "vcf/utils"]:
    init_file = BASE_PATH / pkg / "__init__.py"
    if not init_file.exists():
        init_file.parent.mkdir(parents=True, exist_ok=True)
        init_file.touch()
        print(f"   ✓ {pkg}/__init__.py")
        fixes += 1

# 2. Create data directories
print("\n2️⃣  Creating data directories...")
for dir_name in ["data/raw", "data/processed", "data/panels", "outputs/results", "outputs/figures"]:
    dir_path = BASE_PATH / dir_name
    if not dir_path.exists():
        dir_path.mkdir(parents=True, exist_ok=True)
        print(f"   ✓ {dir_name}/")
        fixes += 1

# 3. Move data files
print("\n3️⃣  Moving data files...")
for old_dir, new_dir in [("data_raw", "data/raw"), ("data_clean", "data/processed")]:
    old_path = BASE_PATH / old_dir
    new_path = BASE_PATH / new_dir
    if old_path.exists():
        for csv_file in old_path.glob("*.csv"):
            new_file = new_path / csv_file.name
            if not new_file.exists():
                shutil.copy2(csv_file, new_file)
                print(f"   ✓ {csv_file.name} → {new_dir}/")
                fixes += 1

# 4. Fix imports in Python files
print("\n4️⃣  Fixing Python imports...")
key_files = [
    "vcf_engine_and_pilots.py",
    "vcf/core/vcf_main.py",
    "vcf/core/vcf_geometry.py",
    "vcf/core/vcf_coherence.py",
    "vcf/core/vcf_normalization.py",
]

for file_name in key_files:
    file_path = BASE_PATH / file_name
    if file_path.exists():
        try:
            with open(file_path, 'r') as f:
                content = f.read()
            original = content
            
            # Backup first
            backup_file = BACKUP_DIR / file_name
            backup_file.parent.mkdir(parents=True, exist_ok=True)
            with open(backup_file, 'w') as f:
                f.write(content)
            
            # Fix imports
            content = re.sub(r'from\s+src\.geometry_engine', 'from vcf.core', content)
            content = re.sub(r'from\s+geometry_engine', 'from vcf.core', content)
            content = re.sub(r'from\s+scripts\.geometry_engine', 'from vcf.core', content)
            content = re.sub(r'from\s+archive\.', 'from vcf.core.', content)
            content = re.sub(r'"data_raw/', '"data/raw/', content)
            content = re.sub(r'"data_clean/', '"data/processed/', content)
            
            if content != original:
                with open(file_path, 'w') as f:
                    f.write(content)
                print(f"   ✓ {file_name}")
                fixes += 1
        except Exception as e:
            print(f"   ⚠ {file_name}: {e}")

# Summary
print("\n" + "═" * 70)
print(f"✅ COMPLETE! Applied {fixes} fixes")
print(f"💾 Backups saved to: {BACKUP_DIR.name}")
print("═" * 70)

# Verify imports work
print("\n5️⃣  Verifying imports...")
import sys
if str(BASE_PATH) not in sys.path:
    sys.path.insert(0, str(BASE_PATH))

all_good = True
for module_name, import_statement in [
    ("vcf_normalization", "from vcf.core.vcf_normalization import VCFNormalizer"),
    ("vcf_geometry", "from vcf.core.vcf_geometry import VCFGeometry"),
    ("vcf_coherence", "from vcf.core.vcf_coherence import VCFCoherence"),
    ("vcf_main", "from vcf.core.vcf_main import VCFEngine"),
]:
    try:
        exec(import_statement)
        print(f"   ✓ {module_name}")
    except Exception as e:
        print(f"   ❌ {module_name}: {e}")
        all_good = False

if all_good:
    print("\n🎉 SUCCESS! Your VCF project is ready for Phase III!")
    print("🚀 You can now run: from vcf.core.vcf_main import VCFEngine")
else:
    print("\n⚠️  Some imports failed. Check the errors above.")
