#!/usr/bin/env python3
"""
VCF Auto-Fix Script for Google Colab
Automatically fixes import patterns and file references in your VCF project
"""

import re
import shutil
from pathlib import Path
from datetime import datetime

class VCFAutoFixer:
    def __init__(self, base_path="/content/drive/MyDrive/VCF-RESEARCH"):
        self.base_path = Path(base_path)
        self.backup_dir = self.base_path / f"_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.fixes_applied = []
        self.errors = []
        
    def backup_file(self, file_path):
        """Create backup of file before modifying"""
        try:
            rel_path = file_path.relative_to(self.base_path)
            backup_path = self.backup_dir / rel_path
            backup_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(file_path, backup_path)
            return True
        except Exception as e:
            self.errors.append(f"Backup failed for {file_path}: {e}")
            return False
    
    def fix_imports_in_file(self, file_path):
        """Fix import statements in a Python file"""
        try:
            with open(file_path, 'r') as f:
                content = f.read()
            
            original_content = content
            changes = []
            
            # Pattern 1: Fix src.geometry_engine imports
            pattern1 = r'from\s+src\.geometry_engine\s+import'
            if re.search(pattern1, content):
                content = re.sub(pattern1, 'from vcf.core import', content)
                changes.append("Fixed src.geometry_engine imports")
            
            # Pattern 2: Fix direct geometry_engine imports
            pattern2 = r'from\s+geometry_engine\s+import'
            if re.search(pattern2, content):
                content = re.sub(pattern2, 'from vcf.core import', content)
                changes.append("Fixed geometry_engine imports")
            
            # Pattern 3: Fix scripts imports
            pattern3 = r'from\s+scripts\.\w+\s+import'
            if re.search(pattern3, content):
                content = re.sub(r'from\s+scripts\.geometry_engine', 'from vcf.core', content)
                content = re.sub(r'from\s+scripts\.data_loader', 'from vcf.data.data_loader', content)
                changes.append("Fixed scripts imports")
            
            # Pattern 4: Fix archive imports
            pattern4 = r'from\s+archive\.'
            if re.search(pattern4, content):
                content = re.sub(pattern4, 'from vcf.core.', content)
                changes.append("Fixed archive imports")
            
            # Pattern 5: Add sys.path setup if importing from vcf but no path setup
            if 'from vcf.' in content and 'sys.path' not in content:
                path_setup = """import sys
from pathlib import Path

# Add project root to Python path
project_root = Path(__file__).parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

"""
                # Insert after initial imports (after import statements)
                import_section_end = 0
                for match in re.finditer(r'^(?:from|import)\s+.*$', content, re.MULTILINE):
                    import_section_end = max(import_section_end, match.end())
                
                if import_section_end > 0:
                    content = content[:import_section_end] + "\n\n" + path_setup + content[import_section_end:]
                    changes.append("Added sys.path setup")
            
            # Pattern 6: Fix data paths
            content = re.sub(r'["\']data_raw/', '"data/raw/', content)
            content = re.sub(r'["\']data_clean/', '"data/processed/', content)
            if 'data_raw' in original_content or 'data_clean' in original_content:
                changes.append("Fixed data paths")
            
            # Only write if changes were made
            if content != original_content:
                if self.backup_file(file_path):
                    with open(file_path, 'w') as f:
                        f.write(content)
                    
                    rel_path = file_path.relative_to(self.base_path)
                    self.fixes_applied.append({
                        'file': str(rel_path),
                        'changes': changes
                    })
                    return True
            
            return False
            
        except Exception as e:
            self.errors.append(f"Error fixing {file_path}: {e}")
            return False
    
    def ensure_init_files(self):
        """Ensure all package directories have __init__.py files"""
        print("=" * 70)
        print("ENSURING __init__.py FILES EXIST")
        print("=" * 70)
        
        package_dirs = [
            "vcf",
            "vcf/core",
            "vcf/data",
            "vcf/analysis",
            "vcf/utils"
        ]
        
        for pkg_dir in package_dirs:
            init_file = self.base_path / pkg_dir / "__init__.py"
            if not init_file.exists():
                try:
                    init_file.parent.mkdir(parents=True, exist_ok=True)
                    init_file.touch()
                    print(f"✓ Created {pkg_dir}/__init__.py")
                    self.fixes_applied.append({
                        'file': f"{pkg_dir}/__init__.py",
                        'changes': ['Created missing __init__.py']
                    })
                except Exception as e:
                    print(f"❌ Failed to create {pkg_dir}/__init__.py: {e}")
                    self.errors.append(f"Failed to create {pkg_dir}/__init__.py: {e}")
            else:
                print(f"  {pkg_dir}/__init__.py exists")
        
        print()
    
    def fix_all_python_files(self):
        """Find and fix all Python files in the project"""
        print("=" * 70)
        print("SCANNING AND FIXING PYTHON FILES")
        print("=" * 70)
        
        # Key files to check
        key_files = [
            "vcf_engine_and_pilots.py",  # Pilot script at root
            "vcf/core/vcf_main.py",
            "vcf/core/vcf_geometry.py",
            "vcf/core/vcf_coherence.py",
            "vcf/core/vcf_normalization.py",
        ]
        
        for file_rel in key_files:
            file_path = self.base_path / file_rel
            if file_path.exists():
                print(f"\nChecking: {file_rel}")
                if self.fix_imports_in_file(file_path):
                    print(f"  ✓ Fixed imports")
                else:
                    print(f"  ℹ No changes needed")
            else:
                print(f"\n⚠ Not found: {file_rel}")
        
        print()
    
    def create_data_directories(self):
        """Ensure proper data directory structure exists"""
        print("=" * 70)
        print("ENSURING DATA DIRECTORY STRUCTURE")
        print("=" * 70)
        
        data_dirs = [
            "data",
            "data/raw",
            "data/processed",
            "data/panels",
            "outputs",
            "outputs/results",
            "outputs/figures"
        ]
        
        for data_dir in data_dirs:
            dir_path = self.base_path / data_dir
            if not dir_path.exists():
                try:
                    dir_path.mkdir(parents=True, exist_ok=True)
                    print(f"✓ Created {data_dir}/")
                    self.fixes_applied.append({
                        'file': f"{data_dir}/",
                        'changes': ['Created directory']
                    })
                except Exception as e:
                    print(f"❌ Failed to create {data_dir}/: {e}")
            else:
                print(f"  {data_dir}/ exists")
        
        print()
    
    def move_data_files(self):
        """Move data files from old locations to new structure"""
        print("=" * 70)
        print("CHECKING DATA FILE LOCATIONS")
        print("=" * 70)
        
        # Check if old data directories exist
        old_raw = self.base_path / "data_raw"
        old_clean = self.base_path / "data_clean"
        new_raw = self.base_path / "data" / "raw"
        new_processed = self.base_path / "data" / "processed"
        
        moved_files = []
        
        # Move from data_raw to data/raw
        if old_raw.exists() and old_raw.is_dir():
            print(f"\nFound old data_raw/ directory")
            for file in old_raw.glob("*.csv"):
                try:
                    new_location = new_raw / file.name
                    if not new_location.exists():
                        shutil.copy2(file, new_location)
                        moved_files.append(f"data_raw/{file.name} → data/raw/{file.name}")
                        print(f"  ✓ Copied {file.name} to data/raw/")
                except Exception as e:
                    print(f"  ❌ Failed to copy {file.name}: {e}")
        
        # Move from data_clean to data/processed
        if old_clean.exists() and old_clean.is_dir():
            print(f"\nFound old data_clean/ directory")
            for file in old_clean.glob("*.csv"):
                try:
                    new_location = new_processed / file.name
                    if not new_location.exists():
                        shutil.copy2(file, new_location)
                        moved_files.append(f"data_clean/{file.name} → data/processed/{file.name}")
                        print(f"  ✓ Copied {file.name} to data/processed/")
                except Exception as e:
                    print(f"  ❌ Failed to copy {file.name}: {e}")
        
        if moved_files:
            print(f"\n✓ Copied {len(moved_files)} data files to new structure")
            print("  Note: Original files left in place for safety")
            self.fixes_applied.append({
                'file': 'data files',
                'changes': moved_files
            })
        else:
            print("\nℹ No data files needed to be moved")
        
        print()
    
    def generate_report(self):
        """Generate a report of all fixes applied"""
        print("=" * 70)
        print("FIX REPORT")
        print("=" * 70)
        
        if self.backup_dir.exists():
            print(f"\n📦 BACKUP LOCATION: {self.backup_dir}")
            print("   Original files backed up before modification")
        
        print(f"\n✅ FIXES APPLIED: {len(self.fixes_applied)}")
        if self.fixes_applied:
            for fix in self.fixes_applied:
                print(f"\n  File: {fix['file']}")
                for change in fix['changes']:
                    print(f"    - {change}")
        else:
            print("  No fixes needed - your structure is already correct!")
        
        if self.errors:
            print(f"\n❌ ERRORS ENCOUNTERED: {len(self.errors)}")
            for error in self.errors:
                print(f"  - {error}")
        
        print("\n" + "=" * 70)
        print("NEXT STEPS")
        print("=" * 70)
        print("""
1. Review the changes above
2. Test your pilot script: 
   from vcf.core.vcf_main import VCFEngine
3. If issues occur, restore from backup:
   {backup_dir}
4. Run your Phase III pilot!
""")
    
    def run_all_fixes(self, dry_run=False):
        """Run all fixes"""
        print("=" * 70)
        print("VCF AUTO-FIX SCRIPT")
        print("=" * 70)
        print(f"Base Path: {self.base_path}")
        
        if dry_run:
            print("MODE: DRY RUN (no changes will be made)")
        else:
            print("MODE: LIVE (changes will be applied)")
            print(f"Backup: {self.backup_dir}")
        
        print()
        
        if not dry_run:
            self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        # Run all fixes
        self.ensure_init_files()
        self.create_data_directories()
        self.move_data_files()
        self.fix_all_python_files()
        
        # Generate report
        self.generate_report()


def main():
    """Main execution function"""
    import sys
    
    # Check if running in Colab
    try:
        from google.colab import drive
        print("✓ Running in Google Colab")
    except:
        print("⚠ Not running in Google Colab - using default path")
    
    print("""
╔═══════════════════════════════════════════════════════════════════╗
║                    VCF AUTO-FIX SCRIPT                            ║
║                                                                   ║
║  This script will automatically fix:                              ║
║  • Import statements (src/scripts → vcf.core)                     ║
║  • Missing __init__.py files                                      ║
║  • Data directory structure                                       ║
║  • Data file locations (data_raw → data/raw)                      ║
║  • sys.path setup in scripts                                      ║
║                                                                   ║
║  Backups will be created before any changes.                      ║
╚═══════════════════════════════════════════════════════════════════╝
    """)
    
    # Ask for confirmation
    response = input("Proceed with fixes? (yes/no/dry-run): ").strip().lower()
    
    if response == 'dry-run':
        print("\n🔍 Running in DRY RUN mode (no changes will be made)...\n")
        fixer = VCFAutoFixer()
        fixer.run_all_fixes(dry_run=True)
    elif response == 'yes':
        print("\n🔧 Applying fixes...\n")
        fixer = VCFAutoFixer()
        fixer.run_all_fixes(dry_run=False)
    else:
        print("\n❌ Cancelled. No changes made.")
        return
    
    print("\n✓ Done!")


if __name__ == "__main__":
    main()
