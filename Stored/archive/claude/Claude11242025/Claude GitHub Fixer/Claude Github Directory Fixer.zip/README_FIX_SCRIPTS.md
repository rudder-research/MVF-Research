# VCF AUTO-FIX SCRIPTS - INSTRUCTIONS

## 🎯 What These Scripts Do

These scripts automatically fix common issues in your VCF project structure:

✅ Fix import statements (`src.geometry_engine` → `vcf.core`)  
✅ Create missing `__init__.py` files  
✅ Set up proper data directory structure  
✅ Move data files from old locations (`data_raw/` → `data/raw/`)  
✅ Add `sys.path` setup where needed  
✅ Create backups before making changes  

---

## 📋 Three Options (Choose One)

### ⚡ OPTION 1: QUICK FIX (Recommended - Easiest)

**Use this if:** You want the fastest, simplest solution

**Steps:**
1. Open Google Colab
2. Create a new cell
3. Copy the entire contents of `VCF_QUICK_FIX.py`
4. Paste into the cell
5. Run the cell
6. Done!

**What it does:** Fixes everything automatically in one go

---

### 🔧 OPTION 2: COLAB CELLS (Best for step-by-step)

**Use this if:** You want to see each step separately

**Steps:**
1. Open `COLAB_CELLS_COPY_PASTE.py`
2. Copy Cell 1 and run it (mounts Drive)
3. Copy Cell 2 and run it (applies fixes)
4. Copy Cell 3 and run it (verifies)
5. Done!

**What it does:** Same as Option 1, but broken into 3 separate cells for clarity

---

### 🎛️ OPTION 3: FULL AUTO-FIX (Most control)

**Use this if:** You want to run dry-run first or need more control

**Steps:**
1. Upload `VCF_AUTO_FIX_FULL.py` to your VCF-RESEARCH folder
2. In Colab, run:
   ```python
   !python /content/drive/MyDrive/VCF-RESEARCH/VCF_AUTO_FIX_FULL.py
   ```
3. Choose: `yes` (apply fixes), `no` (cancel), or `dry-run` (preview)
4. Done!

**What it does:** Same as Option 1, but with interactive confirmation

---

## ✅ After Running Any Script

You should see output like:
```
✅ COMPLETE! Applied 15 fixes
💾 Backups saved to: _backup_20251125_120000
🎉 SUCCESS! Your VCF project is ready for Phase III!
```

### Verify It Worked:

In a new Colab cell, run:
```python
import sys
sys.path.insert(0, '/content/drive/MyDrive/VCF-RESEARCH')

from vcf.core.vcf_main import VCFEngine
from vcf.core.vcf_normalization import VCFNormalizer
from vcf.core.vcf_geometry import VCFGeometry
from vcf.core.vcf_coherence import VCFCoherence

print("✅ All imports working!")
```

If you see no errors, **you're ready for Phase III!**

---

## 🔄 If Something Goes Wrong

All scripts create backups before making changes. To restore:

1. Go to your VCF-RESEARCH folder
2. Find the `_backup_YYYYMMDD_HHMMSS` folder
3. Copy files from backup over the modified files

---

## 📊 What Gets Fixed

### Import Statements
**Before:**
```python
from src.geometry_engine import normalize
from geometry_engine.angles import calculate_angle
```

**After:**
```python
from vcf.core import normalize
from vcf.core.angles import calculate_angle
```

### Data Paths
**Before:**
```python
df = pd.read_csv("data_raw/SPY_US.csv")
```

**After:**
```python
df = pd.read_csv("data/raw/SPY_US.csv")
```

### File Structure
**Before:**
```
VCF-RESEARCH/
├── src/geometry_engine/
├── data_raw/
└── data_clean/
```

**After:**
```
VCF-RESEARCH/
├── vcf/
│   └── core/
├── data/
│   ├── raw/
│   └── processed/
```

---

## 🚀 Next Steps After Running

1. ✅ Verify imports work (see above)
2. 🎯 Run your Phase III pilot script
3. 📊 Check outputs in `outputs/` directory
4. 🎉 Celebrate your working VCF framework!

---

## ❓ FAQ

**Q: Will this delete my files?**  
A: No! It creates backups and only copies/modifies files safely.

**Q: Can I run it multiple times?**  
A: Yes! It's safe to run multiple times. It won't duplicate fixes.

**Q: What if I only want to fix imports?**  
A: The scripts check what needs fixing and only apply necessary changes.

**Q: How do I know which option to use?**  
A: Use **Option 1 (Quick Fix)** - it's the simplest and does everything.

---

## 📝 File Descriptions

| File | Purpose | When to Use |
|------|---------|-------------|
| `VCF_QUICK_FIX.py` | One-command fix | Most people - simplest option |
| `COLAB_CELLS_COPY_PASTE.py` | Step-by-step cells | Want to see each step |
| `VCF_AUTO_FIX_FULL.py` | Interactive fixer | Want dry-run or more control |
| `VCF_IMPORT_REFERENCE.md` | Import guide | Reference for correct patterns |

---

## 🎯 Recommendation

**Just use VCF_QUICK_FIX.py** - Copy and paste it into a Colab cell and run. That's it!

It will fix everything automatically and tell you if it worked. Simple as that.
