# VCF AUTO-FIX - COLAB CELLS
# Copy and paste these cells into your Google Colab notebook

# ═══════════════════════════════════════════════════════════════════
# CELL 1: Mount Google Drive
# ═══════════════════════════════════════════════════════════════════

from google.colab import drive
drive.mount('/content/drive')

# ═══════════════════════════════════════════════════════════════════
# CELL 2: Run Auto-Fix Script
# ═══════════════════════════════════════════════════════════════════

import re
import shutil
from pathlib import Path
from datetime import datetime

class VCFAutoFixer:
    def __init__(self, base_path="/content/drive/MyDrive/VCF-RESEARCH"):
        self.base_path = Path(base_path)
        self.backup_dir = self.base_path / f"_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.fixes_applied = []
        self.errors = []
        
    def backup_file(self, file_path):
        """Create backup of file before modifying"""
        try:
            rel_path = file_path.relative_to(self.base_path)
            backup_path = self.backup_dir / rel_path
            backup_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(file_path, backup_path)
            return True
        except Exception as e:
            self.errors.append(f"Backup failed for {file_path}: {e}")
            return False
    
    def fix_imports_in_file(self, file_path):
        """Fix import statements in a Python file"""
        try:
            with open(file_path, 'r') as f:
                content = f.read()
            
            original_content = content
            changes = []
            
            # Fix various import patterns
            replacements = [
                (r'from\s+src\.geometry_engine', 'from vcf.core', "src.geometry_engine imports"),
                (r'from\s+geometry_engine', 'from vcf.core', "geometry_engine imports"),
                (r'from\s+scripts\.geometry_engine', 'from vcf.core', "scripts imports"),
                (r'from\s+archive\.', 'from vcf.core.', "archive imports"),
            ]
            
            for pattern, replacement, change_desc in replacements:
                if re.search(pattern, content):
                    content = re.sub(pattern, replacement, content)
                    changes.append(f"Fixed {change_desc}")
            
            # Fix data paths
            content = re.sub(r'["\']data_raw/', '"data/raw/', content)
            content = re.sub(r'["\']data_clean/', '"data/processed/', content)
            if 'data_raw' in original_content or 'data_clean' in original_content:
                changes.append("Fixed data paths")
            
            # Add sys.path setup if needed
            if 'from vcf.' in content and 'sys.path' not in content and '__file__' in content:
                path_setup = """import sys
from pathlib import Path

# Add project root to Python path
project_root = Path(__file__).parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

"""
                # Find where to insert (after imports section)
                lines = content.split('\n')
                insert_pos = 0
                for i, line in enumerate(lines):
                    if line.startswith('import ') or line.startswith('from '):
                        insert_pos = i + 1
                
                if insert_pos > 0:
                    lines.insert(insert_pos, path_setup)
                    content = '\n'.join(lines)
                    changes.append("Added sys.path setup")
            
            # Only write if changes were made
            if content != original_content:
                if self.backup_file(file_path):
                    with open(file_path, 'w') as f:
                        f.write(content)
                    
                    rel_path = file_path.relative_to(self.base_path)
                    self.fixes_applied.append({
                        'file': str(rel_path),
                        'changes': changes
                    })
                    return True
            
            return False
            
        except Exception as e:
            self.errors.append(f"Error fixing {file_path}: {e}")
            return False
    
    def ensure_init_files(self):
        """Ensure all package directories have __init__.py files"""
        print("📦 Ensuring __init__.py files...")
        
        package_dirs = ["vcf", "vcf/core", "vcf/data", "vcf/analysis", "vcf/utils"]
        
        for pkg_dir in package_dirs:
            init_file = self.base_path / pkg_dir / "__init__.py"
            if not init_file.exists():
                try:
                    init_file.parent.mkdir(parents=True, exist_ok=True)
                    init_file.touch()
                    print(f"  ✓ Created {pkg_dir}/__init__.py")
                    self.fixes_applied.append({'file': f"{pkg_dir}/__init__.py", 'changes': ['Created']})
                except Exception as e:
                    print(f"  ❌ Failed: {pkg_dir}/__init__.py")
        print()
    
    def create_data_directories(self):
        """Ensure proper data directory structure exists"""
        print("📁 Ensuring data directories...")
        
        data_dirs = ["data", "data/raw", "data/processed", "data/panels", 
                     "outputs", "outputs/results", "outputs/figures"]
        
        for data_dir in data_dirs:
            dir_path = self.base_path / data_dir
            if not dir_path.exists():
                try:
                    dir_path.mkdir(parents=True, exist_ok=True)
                    print(f"  ✓ Created {data_dir}/")
                except Exception as e:
                    print(f"  ❌ Failed: {data_dir}/")
        print()
    
    def move_data_files(self):
        """Copy data files from old locations to new structure"""
        print("📋 Checking data file locations...")
        
        old_raw = self.base_path / "data_raw"
        old_clean = self.base_path / "data_clean"
        new_raw = self.base_path / "data" / "raw"
        new_processed = self.base_path / "data" / "processed"
        
        moved_count = 0
        
        if old_raw.exists():
            for file in old_raw.glob("*.csv"):
                new_location = new_raw / file.name
                if not new_location.exists():
                    shutil.copy2(file, new_location)
                    moved_count += 1
                    print(f"  ✓ Copied {file.name} → data/raw/")
        
        if old_clean.exists():
            for file in old_clean.glob("*.csv"):
                new_location = new_processed / file.name
                if not new_location.exists():
                    shutil.copy2(file, new_location)
                    moved_count += 1
                    print(f"  ✓ Copied {file.name} → data/processed/")
        
        if moved_count == 0:
            print("  ℹ No data files needed moving")
        print()
    
    def fix_all_python_files(self):
        """Fix imports in key Python files"""
        print("🔧 Fixing Python imports...")
        
        key_files = [
            "vcf_engine_and_pilots.py",
            "vcf/core/vcf_main.py",
            "vcf/core/vcf_geometry.py",
            "vcf/core/vcf_coherence.py",
            "vcf/core/vcf_normalization.py",
        ]
        
        for file_rel in key_files:
            file_path = self.base_path / file_rel
            if file_path.exists():
                if self.fix_imports_in_file(file_path):
                    print(f"  ✓ Fixed {file_rel}")
                else:
                    print(f"  ℹ {file_rel} - no changes needed")
            else:
                print(f"  ⚠ {file_rel} - not found")
        print()
    
    def run_all_fixes(self):
        """Run all fixes"""
        print("═" * 70)
        print("🚀 VCF AUTO-FIX STARTING")
        print("═" * 70)
        print(f"Project: {self.base_path}")
        print(f"Backup: {self.backup_dir}\n")
        
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        self.ensure_init_files()
        self.create_data_directories()
        self.move_data_files()
        self.fix_all_python_files()
        
        print("═" * 70)
        print("📊 SUMMARY")
        print("═" * 70)
        print(f"✅ Changes applied: {len(self.fixes_applied)}")
        
        if self.fixes_applied:
            print("\nChanges made:")
            for fix in self.fixes_applied[:10]:  # Show first 10
                print(f"  • {fix['file']}")
                for change in fix['changes'][:3]:  # Show first 3 changes per file
                    print(f"    - {change}")
        else:
            print("✓ No fixes needed - structure is correct!")
        
        if self.errors:
            print(f"\n⚠ Errors: {len(self.errors)}")
            for error in self.errors[:5]:
                print(f"  • {error}")
        
        print("\n✅ DONE! Your VCF project is now properly structured.")
        print(f"💾 Backup saved to: {self.backup_dir.name}")
        print("\n🎯 Next step: Run your Phase III pilot!")

# RUN THE FIXER
fixer = VCFAutoFixer()
fixer.run_all_fixes()

# ═══════════════════════════════════════════════════════════════════
# CELL 3: Verify the fixes worked
# ═══════════════════════════════════════════════════════════════════

print("🔍 VERIFICATION\n")

import sys
sys.path.insert(0, '/content/drive/MyDrive/VCF-RESEARCH')

try:
    from vcf.core.vcf_normalization import VCFNormalizer
    print("✅ vcf.core.vcf_normalization - imports successfully")
except Exception as e:
    print(f"❌ vcf_normalization import failed: {e}")

try:
    from vcf.core.vcf_geometry import VCFGeometry
    print("✅ vcf.core.vcf_geometry - imports successfully")
except Exception as e:
    print(f"❌ vcf_geometry import failed: {e}")

try:
    from vcf.core.vcf_coherence import VCFCoherence
    print("✅ vcf.core.vcf_coherence - imports successfully")
except Exception as e:
    print(f"❌ vcf_coherence import failed: {e}")

try:
    from vcf.core.vcf_main import VCFEngine
    print("✅ vcf.core.vcf_main - imports successfully")
except Exception as e:
    print(f"❌ vcf_main import failed: {e}")

print("\n✅ All imports working! Ready for Phase III pilot run!")
