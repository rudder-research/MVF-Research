#!/usr/bin/env python3
"""
Quick diagnostic to check if vcf_engine_and_pilots.py has correct imports
"""

import re
from pathlib import Path

def analyze_pilot_script(script_path="/content/drive/MyDrive/VCF-RESEARCH/vcf_engine_and_pilots.py"):
    """Analyze pilot script for correct import patterns"""
    
    script_path = Path(script_path)
    
    if not script_path.exists():
        print("❌ ERROR: vcf_engine_and_pilots.py not found at expected location!")
        print(f"   Expected: {script_path}")
        print("\n💡 SOLUTION: Make sure your pilot script is at project root:")
        print("   /content/drive/MyDrive/VCF-RESEARCH/vcf_engine_and_pilots.py")
        return
    
    print("=" * 70)
    print("ANALYZING: vcf_engine_and_pilots.py")
    print("=" * 70)
    print()
    
    # Read the script
    with open(script_path, 'r') as f:
        content = f.read()
    
    # Check for path setup
    print("1. PATH SETUP CHECK:")
    if 'sys.path' in content:
        print("   ✓ Script includes sys.path modification")
    else:
        print("   ⚠ Script may need sys.path setup")
        print("     Add this at the top:")
        print("     import sys")
        print("     from pathlib import Path")
        print("     sys.path.insert(0, str(Path(__file__).parent))")
    print()
    
    # Check imports
    print("2. IMPORT ANALYSIS:")
    
    # Find all imports
    import_pattern = r'^(?:from|import)\s+([^\s]+)'
    imports = re.findall(import_pattern, content, re.MULTILINE)
    
    correct_imports = []
    incorrect_imports = []
    
    for imp in imports:
        if imp.startswith('vcf.core') or imp.startswith('vcf.data') or imp.startswith('vcf.utils'):
            correct_imports.append(imp)
        elif any(x in imp for x in ['src.', 'scripts.', 'geometry_engine', 'archive']):
            incorrect_imports.append(imp)
    
    if correct_imports:
        print("   ✓ CORRECT IMPORTS FOUND:")
        for imp in set(correct_imports):
            print(f"     - {imp}")
    else:
        print("   ⚠ No imports from vcf package found")
    
    print()
    
    if incorrect_imports:
        print("   ❌ INCORRECT IMPORTS FOUND:")
        for imp in set(incorrect_imports):
            print(f"     - {imp}")
        print("\n   💡 REPLACE WITH:")
        print("     from vcf.core.vcf_normalization import VCFNormalizer")
        print("     from vcf.core.vcf_geometry import VCFGeometry")
        print("     from vcf.core.vcf_coherence import VCFCoherence")
        print("     from vcf.core.vcf_main import VCFEngine")
    else:
        print("   ✓ No legacy imports detected")
    
    print()
    
    # Check data paths
    print("3. DATA PATH CHECK:")
    if 'data/raw' in content or 'data/processed' in content:
        print("   ✓ Uses correct data paths (data/raw, data/processed)")
    elif 'data_raw' in content or 'data_clean' in content:
        print("   ⚠ Uses legacy data paths (data_raw, data_clean)")
        print("     Consider updating to: data/raw, data/processed")
    else:
        print("   ℹ No data paths detected in script")
    
    print()
    
    # Summary
    print("=" * 70)
    print("SUMMARY:")
    print("=" * 70)
    
    if correct_imports and not incorrect_imports:
        print("✓ Your script appears to have correct imports!")
        print("✓ Ready for Phase III pilot run")
    else:
        print("⚠ Your script needs updates:")
        if not correct_imports:
            print("  - Add imports from vcf.core package")
        if incorrect_imports:
            print("  - Remove legacy imports from src/scripts/archive")
    
    print()


def check_core_modules_exist():
    """Verify all core modules exist"""
    print("=" * 70)
    print("VERIFYING CORE MODULES EXIST")
    print("=" * 70)
    print()
    
    base = Path("/content/drive/MyDrive/VCF-RESEARCH")
    
    modules = [
        "vcf/__init__.py",
        "vcf/core/__init__.py",
        "vcf/core/vcf_normalization.py",
        "vcf/core/vcf_geometry.py",
        "vcf/core/vcf_coherence.py",
        "vcf/core/vcf_main.py",
        "vcf/data/__init__.py",
        "vcf/utils/__init__.py"
    ]
    
    all_exist = True
    for module in modules:
        path = base / module
        if path.exists():
            print(f"✓ {module}")
        else:
            print(f"❌ {module} - MISSING!")
            all_exist = False
    
    print()
    if all_exist:
        print("✓ All required modules exist!")
    else:
        print("❌ Some modules are missing - check above")
    
    print()


if __name__ == "__main__":
    check_core_modules_exist()
    analyze_pilot_script()
    
    print("=" * 70)
    print("QUICK REFERENCE:")
    print("=" * 70)
    print("""
Your pilot script should look like this:

    import sys
    from pathlib import Path
    import pandas as pd
    import numpy as np
    
    # Add project root to path
    project_root = Path(__file__).parent
    sys.path.insert(0, str(project_root))
    
    # Import VCF modules
    from vcf.core.vcf_normalization import VCFNormalizer
    from vcf.core.vcf_geometry import VCFGeometry
    from vcf.core.vcf_coherence import VCFCoherence
    from vcf.core.vcf_main import VCFEngine
    
    # Your pilot code here...
    """)
