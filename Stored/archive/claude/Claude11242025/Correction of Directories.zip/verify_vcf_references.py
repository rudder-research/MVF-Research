#!/usr/bin/env python3
"""
VCF Reference Verification Script
Checks that all imports and file paths are correctly referenced in your project
"""

import os
from pathlib import Path

class VCFReferenceChecker:
    def __init__(self, base_path="/content/drive/MyDrive/VCF-RESEARCH"):
        self.base_path = Path(base_path)
        self.issues = []
        self.warnings = []
        
    def check_structure(self):
        """Verify the expected directory structure exists"""
        print("=" * 60)
        print("CHECKING VCF PROJECT STRUCTURE")
        print("=" * 60)
        
        expected_dirs = [
            "vcf",
            "vcf/core",
            "vcf/data",
            "vcf/analysis",
            "vcf/utils",
            "data",
            "data/raw",
            "data/processed",
            "outputs",
            "scripts",
            "tests"
        ]
        
        for dir_path in expected_dirs:
            full_path = self.base_path / dir_path
            if full_path.exists():
                print(f"✓ {dir_path}")
            else:
                self.issues.append(f"Missing directory: {dir_path}")
                print(f"✗ {dir_path} - MISSING")
        
        print()
    
    def check_vcf_package(self):
        """Check VCF package structure and __init__ files"""
        print("=" * 60)
        print("CHECKING VCF PACKAGE STRUCTURE")
        print("=" * 60)
        
        package_dirs = [
            "vcf",
            "vcf/core",
            "vcf/data",
            "vcf/analysis",
            "vcf/utils"
        ]
        
        for pkg_dir in package_dirs:
            init_file = self.base_path / pkg_dir / "__init__.py"
            if init_file.exists():
                print(f"✓ {pkg_dir}/__init__.py exists")
            else:
                self.warnings.append(f"Missing __init__.py in {pkg_dir}")
                print(f"⚠ {pkg_dir}/__init__.py - MISSING (package may not import correctly)")
        
        print()
    
    def check_core_modules(self):
        """Check that core VCF modules exist"""
        print("=" * 60)
        print("CHECKING CORE VCF MODULES")
        print("=" * 60)
        
        core_modules = [
            "vcf/core/vcf_normalization.py",
            "vcf/core/vcf_geometry.py",
            "vcf/core/vcf_coherence.py",
            "vcf/core/vcf_main.py"
        ]
        
        for module in core_modules:
            module_path = self.base_path / module
            if module_path.exists():
                print(f"✓ {module}")
            else:
                self.issues.append(f"Missing core module: {module}")
                print(f"✗ {module} - MISSING")
        
        print()
    
    def analyze_import_patterns(self):
        """Analyze common import patterns that should work"""
        print("=" * 60)
        print("RECOMMENDED IMPORT PATTERNS")
        print("=" * 60)
        
        print("\nFrom project root scripts (like vcf_engine_and_pilots.py):")
        print("  from vcf.core.vcf_normalization import VCFNormalizer")
        print("  from vcf.core.vcf_geometry import VCFGeometry")
        print("  from vcf.core.vcf_coherence import VCFCoherence")
        print("  from vcf.core.vcf_main import VCFEngine")
        
        print("\nFrom within vcf/core/ modules:")
        print("  from .vcf_normalization import VCFNormalizer")
        print("  from .vcf_geometry import VCFGeometry")
        print("  # OR:")
        print("  from vcf.core.vcf_normalization import VCFNormalizer")
        
        print("\nFrom data loading scripts:")
        print("  from vcf.data.data_loader import load_data")
        
        print()
    
    def check_legacy_code(self):
        """Identify legacy code that might cause confusion"""
        print("=" * 60)
        print("LEGACY CODE LOCATIONS (may cause import conflicts)")
        print("=" * 60)
        
        legacy_paths = [
            "src/geometry_engine",
            "archive/old_geometry_engine",
            "_backup_before_reorganization"
        ]
        
        for legacy_path in legacy_paths:
            full_path = self.base_path / legacy_path
            if full_path.exists():
                self.warnings.append(f"Legacy code found at {legacy_path}")
                print(f"⚠ {legacy_path} - Consider removing or documenting")
        
        print("\nRECOMMENDATION: Ensure scripts import from 'vcf' package, not legacy paths")
        print()
    
    def check_pilot_script_location(self):
        """Check pilot script location"""
        print("=" * 60)
        print("CHECKING PILOT SCRIPT")
        print("=" * 60)
        
        pilot_script = self.base_path / "vcf_engine_and_pilots.py"
        if pilot_script.exists():
            print(f"✓ vcf_engine_and_pilots.py found at project root")
            print("  This location is CORRECT for running with 'from vcf.core import ...'")
        else:
            self.warnings.append("Pilot script not found at expected location")
            print("⚠ vcf_engine_and_pilots.py not found at project root")
        
        print()
    
    def generate_path_setup_code(self):
        """Generate code to add to scripts for proper path setup"""
        print("=" * 60)
        print("PATH SETUP CODE FOR SCRIPTS")
        print("=" * 60)
        
        print("""
# Add this at the top of scripts in project root:
import sys
from pathlib import Path

# Add project root to Python path
project_root = Path(__file__).parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# Now you can import from vcf package
from vcf.core.vcf_normalization import VCFNormalizer
from vcf.core.vcf_geometry import VCFGeometry
from vcf.core.vcf_coherence import VCFCoherence
from vcf.core.vcf_main import VCFEngine
""")
        print()
    
    def check_data_paths(self):
        """Check data directory structure"""
        print("=" * 60)
        print("CHECKING DATA PATHS")
        print("=" * 60)
        
        data_structure = {
            "data/raw": "Raw data files (CSV, XLSX)",
            "data/processed": "Processed/normalized data",
            "data/panels": "Panel data outputs"
        }
        
        for data_dir, description in data_structure.items():
            full_path = self.base_path / data_dir
            if full_path.exists():
                print(f"✓ {data_dir} - {description}")
            else:
                self.warnings.append(f"Data directory missing: {data_dir}")
                print(f"⚠ {data_dir} - {description} - MISSING")
        
        print()
    
    def run_full_check(self):
        """Run all verification checks"""
        self.check_structure()
        self.check_vcf_package()
        self.check_core_modules()
        self.check_legacy_code()
        self.check_pilot_script_location()
        self.check_data_paths()
        self.analyze_import_patterns()
        self.generate_path_setup_code()
        
        # Summary
        print("=" * 60)
        print("VERIFICATION SUMMARY")
        print("=" * 60)
        
        if not self.issues and not self.warnings:
            print("✓ ALL CHECKS PASSED!")
            print("Your VCF project structure appears correct.")
        else:
            if self.issues:
                print(f"\n❌ CRITICAL ISSUES ({len(self.issues)}):")
                for issue in self.issues:
                    print(f"  - {issue}")
            
            if self.warnings:
                print(f"\n⚠ WARNINGS ({len(self.warnings)}):")
                for warning in self.warnings:
                    print(f"  - {warning}")
        
        print()
        print("=" * 60)
        print("NEXT STEPS")
        print("=" * 60)
        print("1. Review any critical issues above")
        print("2. Ensure your pilot script uses: from vcf.core import ...")
        print("3. Add path setup code if needed (see above)")
        print("4. Remove or ignore legacy code in src/ and archive/")
        print("=" * 60)


if __name__ == "__main__":
    checker = VCFReferenceChecker()
    checker.run_full_check()
