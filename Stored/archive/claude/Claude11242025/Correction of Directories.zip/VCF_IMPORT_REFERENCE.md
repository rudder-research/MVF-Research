# VCF PROJECT IMPORT REFERENCE GUIDE

## Current Structure
```
VCF-RESEARCH/
├── vcf/                          # Main package (USE THIS)
│   ├── __init__.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── vcf_normalization.py
│   │   ├── vcf_geometry.py
│   │   ├── vcf_coherence.py
│   │   └── vcf_main.py
│   ├── data/
│   │   ├── __init__.py
│   │   ├── data_loader.py
│   │   └── build_macro_panel.py
│   ├── analysis/
│   │   └── __init__.py
│   └── utils/
│       ├── __init__.py
│       ├── vcf_advanced_math.py
│       └── vcf_visualizations.py
├── data/                         # Data files
├── scripts/                      # Standalone scripts (legacy?)
├── src/                          # OLD - DO NOT USE
└── vcf_engine_and_pilots.py     # Your pilot script (root level)
```

## ✅ CORRECT IMPORTS

### From Root-Level Scripts (vcf_engine_and_pilots.py)

```python
import sys
from pathlib import Path

# Ensure project root is in path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

# Now import from vcf package
from vcf.core.vcf_normalization import VCFNormalizer
from vcf.core.vcf_geometry import VCFGeometry
from vcf.core.vcf_coherence import VCFCoherence
from vcf.core.vcf_main import VCFEngine
from vcf.data.data_loader import load_data
from vcf.utils.vcf_visualizations import create_plots
```

### From Within vcf/core/ Modules

**Option 1: Relative imports (recommended within package)**
```python
# Inside vcf/core/vcf_main.py
from .vcf_normalization import VCFNormalizer
from .vcf_geometry import VCFGeometry
from .vcf_coherence import VCFCoherence
```

**Option 2: Absolute imports**
```python
# Inside vcf/core/vcf_main.py
from vcf.core.vcf_normalization import VCFNormalizer
from vcf.core.vcf_geometry import VCFGeometry
from vcf.core.vcf_coherence import VCFCoherence
```

### From Google Colab Notebooks

```python
import sys
from pathlib import Path

# Mount Google Drive
from google.colab import drive
drive.mount('/content/drive')

# Add VCF-RESEARCH to path
project_path = '/content/drive/MyDrive/VCF-RESEARCH'
if project_path not in sys.path:
    sys.path.insert(0, project_path)

# Now import normally
from vcf.core.vcf_main import VCFEngine
from vcf.core.vcf_normalization import VCFNormalizer
```

## ❌ INCORRECT IMPORTS (DO NOT USE)

```python
# DON'T use src/ - it's legacy code
from src.geometry_engine import ...  # ❌

# DON'T use scripts/ directly
from scripts.geometry_engine import ...  # ❌

# DON'T use archive/
from archive.old_geometry_engine import ...  # ❌
```

## 🔍 KEY FILES AND THEIR CORRECT LOCATIONS

| File Purpose | Correct Location | Import As |
|--------------|------------------|-----------|
| Normalization | `vcf/core/vcf_normalization.py` | `from vcf.core.vcf_normalization import VCFNormalizer` |
| Geometry | `vcf/core/vcf_geometry.py` | `from vcf.core.vcf_geometry import VCFGeometry` |
| Coherence | `vcf/core/vcf_coherence.py` | `from vcf.core.vcf_coherence import VCFCoherence` |
| Main Engine | `vcf/core/vcf_main.py` | `from vcf.core.vcf_main import VCFEngine` |
| Data Loading | `vcf/data/data_loader.py` | `from vcf.data.data_loader import load_data` |
| Visualizations | `vcf/utils/vcf_visualizations.py` | `from vcf.utils.vcf_visualizations import *` |

## 📋 CHECKLIST FOR YOUR PILOT SCRIPT

- [ ] Script is at project root: `VCF-RESEARCH/vcf_engine_and_pilots.py`
- [ ] Adds project root to sys.path (see code above)
- [ ] Uses `from vcf.core import ...` pattern
- [ ] Does NOT import from `src/` or `scripts/`
- [ ] Data paths reference `data/raw/` and `data/processed/`
- [ ] Outputs go to `outputs/` or `Outputs/Pilot 002/`

## 🔧 QUICK FIX FOR EXISTING SCRIPTS

If you have a script with wrong imports, replace:

```python
# Old (wrong)
from geometry_engine import *
from src.vcf import *

# New (correct)
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from vcf.core.vcf_normalization import VCFNormalizer
from vcf.core.vcf_geometry import VCFGeometry
from vcf.core.vcf_coherence import VCFCoherence
from vcf.core.vcf_main import VCFEngine
```

## 📊 DATA FILE PATHS

```python
# Correct data paths (relative to project root)
RAW_DATA = "data/raw/"
PROCESSED_DATA = "data/processed/"
OUTPUTS = "outputs/results/"

# Or use absolute paths
from pathlib import Path
PROJECT_ROOT = Path(__file__).parent
RAW_DATA = PROJECT_ROOT / "data" / "raw"
```

## ⚠️ COMMON ISSUES

1. **ModuleNotFoundError**: Add project root to sys.path (see above)
2. **ImportError from legacy code**: Make sure you're NOT importing from src/ or archive/
3. **Circular imports**: Use relative imports within the same package
4. **Missing __init__.py**: Each package directory needs one (even if empty)

## 🚀 READY FOR PHASE III?

Your structure is correct if:
- ✅ All core modules are in `vcf/core/`
- ✅ Your pilot script imports with `from vcf.core import ...`
- ✅ Legacy code in `src/` and `archive/` is ignored
- ✅ Data paths point to `data/raw/` and `data/processed/`
