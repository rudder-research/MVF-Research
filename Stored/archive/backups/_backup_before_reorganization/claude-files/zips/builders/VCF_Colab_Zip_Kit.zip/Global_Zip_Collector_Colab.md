
# Global ZIP Collector — Colab Version

This file contains the full Global Archive Collector code:
- Creates master archive
- Upload system for ChatGPT, Claude, GitHub repos
- Auto-index
- ZIP export
- Optional Drive-saving extension

(All code cells preserved exactly as sent earlier.)
